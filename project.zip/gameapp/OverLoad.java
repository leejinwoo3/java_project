package gameapp;

public interface OverLoad {
	public String getCh(int score);
}
