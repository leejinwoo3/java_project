package utils;

public class Define {
	public static final int CARDAN = 1001;
	public static final int LUPEON = 2001;
	public static final int AZEROTH = 3001;

	
	public static final int AB_TYPE = 0;
	public static final int SAB_TYPE = 1;
	public static final int DAB_TYPE = 2;
	
}
